package com.czxy.util;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/5
 * 来提供状态数据的 工具类
 * 专门提供 成功1  失败0
 */
public class CommonUtil {

    /**
     * 静态常量，失败0
     */
    public final static Integer FALL = 0;

    /**
     * 静态常量，成功1
     */
    public final static Integer SUCCESS = 1;

    public static Integer getFALL() {
        return FALL;
    }

    public static Integer getSUCCESS() {
        return SUCCESS;
    }
}
