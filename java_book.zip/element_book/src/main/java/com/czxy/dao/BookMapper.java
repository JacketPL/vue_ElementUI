package com.czxy.dao;

import com.czxy.pojo.Book;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Properties;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/10/26
 * @jdk 1.8
 */
@Mapper
public interface BookMapper extends tk.mybatis.mapper.common.Mapper<Book> {
    /**
     * javadoc注释
     * @Author: kedaya
     * @Description: 查询所有book
     * @Date: 2019/10/26
     * @return: java.util.List<com.czxy.pojo.Book>
     **/
    @Select("select * from t_book where title like '%${search}%'")
    @Results(id = "setCate",value = {
            @Result(property = "category" , one = @One(select = "com.czxy.dao.CategoryMapper.selectByPrimaryKey") , column = "category_id"),
            @Result(property = "category_Id" ,  column = "category_id")
    })
    List<Book> findAll(@Param("search") String search);



//    @Results({
//            @Result(property = "category" , one = @One(select = "com.czxy.dao.CategoryMapper.selectByPrimaryKey") , column = "category_id"),
//            @Result(property = "category_Id" ,  column = "category_id")
//    })
    @ResultMap("setCate")
    @Select("select * from t_book where bid = #{bid}")
    Book findByBid(@Param("bid") Integer bid);

    @Update("update t_book set category_id = null where category_id = #{gid}")
    void delCategory_Id(@Param("gid") Integer gid);
}
