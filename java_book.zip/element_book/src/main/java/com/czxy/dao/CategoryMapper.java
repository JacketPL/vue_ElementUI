package com.czxy.dao;

import com.czxy.pojo.Category;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/10/26
 * @jdk 1.8
 */
@Mapper
public interface CategoryMapper extends tk.mybatis.mapper.common.Mapper<Category> {
}
