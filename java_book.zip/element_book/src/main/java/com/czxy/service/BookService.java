package com.czxy.service;

import com.czxy.dao.BookMapper;
import com.czxy.dao.CategoryMapper;
import com.czxy.pojo.Book;
import com.czxy.pojo.Category;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/10/26
 * @jdk 1.8
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class BookService {

    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private CategoryMapper categoryMapper;

//    public List<Book> findAll(){
//       return bookMapper.findAll();
//    }

    public PageInfo<Book> findAll(Integer pageNum , String search){
        PageHelper.startPage(pageNum , 3);
        //带分页
        search = search.equals("null") ? "" : search;
        List<Book> books = bookMapper.findAll(search);
        //每页五条数据
        PageInfo<Book> pageInfo = new PageInfo<Book>(books);
        return pageInfo;
    }

    public void addBook(Book book) {
        bookMapper.insert(book);
    }

    public Book findByBid(Integer bid) {
        return bookMapper.findByBid(bid);
    }

    public void update(Book book) {
        bookMapper.updateByPrimaryKeySelective(book);
    }

    public void delBook(Integer bid) {
        bookMapper.deleteByPrimaryKey(bid);
    }

    public List<Category> getCategory() {
        return categoryMapper.selectAll();
    }

    public void delCategory(Integer gid) {
        //先删除 book表中的 外键字段
        bookMapper.delCategory_Id(gid);
        //再删除 gid的分类
        categoryMapper.deleteByPrimaryKey(gid);
    }

    public void addCategory(Category category) {
        categoryMapper.insert(category);
    }

    public Category getCategoryById(Integer cid) {
        return categoryMapper.selectByPrimaryKey(cid);
    }

    public void categoryUpdate(Category category) {
        categoryMapper.updateByPrimaryKeySelective(category);
    }

    public void delAllBook(Book[] books) {
        //批量删除
        for (Book book : books) {
            bookMapper.delete(book);
        }
    }

    public void delAllCategory(Category[] categories) {
        //先删除 book表中的 外键字段
        for (Category category : categories) {
            bookMapper.delCategory_Id(category.getCid());
        }

        //批量删除
        for (Category category : categories) {
            categoryMapper.delete(category);
        }
    }
}
