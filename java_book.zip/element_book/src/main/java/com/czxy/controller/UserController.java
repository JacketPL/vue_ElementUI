package com.czxy.controller;

import com.czxy.pojo.User;
import com.czxy.povo.BaseResult;
import com.czxy.util.CommonUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/10/26
 * @jdk 1.8
 */
@RestController
@RequestMapping("/user")
public class UserController {
    private static List<User> users = new ArrayList<>();
    //静态代码块
    static {
        users.add(new User(1,"admin","admin"));
        users.add(new User(2,"张三","123"));
    }

    @PostMapping
    public ResponseEntity<BaseResult> login(@RequestBody User user , HttpServletRequest request){

        BaseResult br = null;

        //判断是否匹配user
        for (User thisUser : users) {
            if (thisUser.getUsername().equals(user.getUsername()) && thisUser.getPassword().equals(user.getPassword())){
                //存储session
                request.getSession().setAttribute("loginUser",thisUser);
                br = new BaseResult(CommonUtil.getSUCCESS() , "登录成功" , thisUser);
                return ResponseEntity.ok(br);
            }
        }
        //上面没有返回
        br = new BaseResult(CommonUtil.getFALL() , "账户或密码错误" , null);
        return ResponseEntity.ok(br);
    }

    @GetMapping
    public ResponseEntity<BaseResult> condUser(HttpServletRequest request){
        //判断是否登录了
        User loginUser = (User) request.getSession().getAttribute("loginUser");
        if (loginUser == null){
            return ResponseEntity.ok(new BaseResult(CommonUtil.getFALL() , "查询用户失败" ,null));
        }
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "查询用户成功" ,loginUser));
    }

    @GetMapping("/logout")
    public ResponseEntity<BaseResult> logout(HttpServletRequest request){
        //清除session
        request.getSession().invalidate();
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "登出成功" ,null));
    }
}
