package com.czxy.controller;

import com.czxy.pojo.Book;
import com.czxy.pojo.Category;
import com.czxy.povo.BaseResult;
import com.czxy.service.BookService;
import com.czxy.util.CommonUtil;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/10/26
 * @jdk 1.8
 */
@RestController
@RequestMapping("/book")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/getAll/{pageNum}/{search}")
    public ResponseEntity<BaseResult> findAll(@PathVariable Integer pageNum , @PathVariable String search){
        BaseResult br = null;
        //带分页 pageNum为分页  search为模糊查询的条件
        //查询所有的book  带分页，并且具有查询条件的查询
        PageInfo<Book> books = bookService.findAll(pageNum , search);
        br = new BaseResult(CommonUtil.getSUCCESS() , "查询成功" , books);
        return ResponseEntity.ok(br);
    }

    @PostMapping
    public ResponseEntity<BaseResult> addBook(@RequestBody Book book){
        bookService.addBook(book);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "添加成功" , null));
    }

    @GetMapping("/{bid}")
    public ResponseEntity<BaseResult> findByBid(@PathVariable Integer bid){
        Book book = bookService.findByBid(bid);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "查询成功" , book));
    }

    @PutMapping
    public ResponseEntity<BaseResult> update(@RequestBody Book book){
        bookService.update(book);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "修改成功" , null));
    }

    @DeleteMapping("/{bid}")
    public ResponseEntity<BaseResult> delBook(@PathVariable Integer bid){
        bookService.delBook(bid);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "删除成功" , null));
    }

    /**
      * javadoc注释
      * @Author: kedaya
      * @Description: 获取所有的分类
      * @Date: 2019/10/28
      * @param
      * @return: org.springframework.http.ResponseEntity<java.util.List<com.czxy.pojo.Category>>
      */
    @GetMapping("/getCategory")
    public ResponseEntity<BaseResult> getCategory(){
        List<Category> categories = bookService.getCategory();
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "查询成功" , categories));
    }

    @DeleteMapping("/delCategory/{gid}")
    public ResponseEntity<BaseResult> delCategory(@PathVariable Integer gid){
        bookService.delCategory(gid);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "删除成功" , null));
    }

    @PutMapping("/delAllCategory")
    public ResponseEntity<BaseResult> delAllCategory(@RequestBody Category[] categories){
        //批量删除 category分类
        bookService.delAllCategory(categories);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "删除成功" , null));
    }

    @PostMapping("/addCategory")
    public ResponseEntity<BaseResult> addCategory(@RequestBody Category category){
        bookService.addCategory(category);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "添加成功" , null));
    }

    @GetMapping("/getCategoryById/{cid}")
    public ResponseEntity<BaseResult> getCategoryById(@PathVariable Integer cid){
        Category category = bookService.getCategoryById(cid);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "查询成功" , category));
    }

    @PutMapping("/categoryUpdate")
    public ResponseEntity<BaseResult> categoryUpdate(@RequestBody Category category){
        bookService.categoryUpdate(category);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "修改成功" , null));
    }

    @PutMapping("/delAllBook")
    public ResponseEntity<BaseResult> delAllBook(@RequestBody Book[] books){
        //批量删除 book
        bookService.delAllBook(books);
        return ResponseEntity.ok(new BaseResult(CommonUtil.getSUCCESS() , "删除成功" , null));
    }
}
