package com.czxy.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import javax.persistence.Id;

/**
 * @Description  
 * @Author  Baby
 * @Date 2019-10-26 
 */

@Entity
@Table ( name ="t_category" )
public class Category implements Serializable {

	private static final long SERIAL_VERSION_UID =  8015355194516258426L;

	@Id
   	@Column(name = "cid" )
	private Integer cid;

   	@Column(name = "cname" )
	private String cname;

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

}
