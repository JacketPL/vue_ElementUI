package com.czxy.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import javax.persistence.Id;

/**
 * @Description  
 * @Author  Baby
 * @Date 2019-10-26 
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table ( name ="t_book" )
public class Book implements Serializable {

	private static final long SERIAL_VERSION_UID =  7758706937882524184L;

	@Id
   	@Column(name = "bid" )
	private Integer bid;

   	@Column(name = "title" )
	private String title;

   	@Column(name = "price" )
	private Double price;

   	@Column(name = "category_id" )
	private Integer category_Id;


	/**
	 * 在Book中 有一个 Category分类的对象
	 */
	private Category category;



}
