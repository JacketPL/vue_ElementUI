package com.czxy.povo;

/**
 * @author 遗憾就遗憾吧
 * @Date 2019/11/5
 * 请求结果的返回类
 * 企业级开发中，所使用的规范，返回值都返回 BaseResult返回类，
 * code提供状态  msg为信息  data为数据
 * 服务器返回的状态码 统一 200。 使用ResponseEntity.ok()返回
 */
public class BaseResult {


    /**
     * 请求返回的 状态码
     * 0为失败
     * 1为成功
     */
    private Integer code;


    /**
     * 返回的状态信息字符串
     */
    private String msg;

    /**
     * 返回的数据
     */
    private Object data;

    public BaseResult() {
    }

    public BaseResult(Integer code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
