import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import axios from 'axios'
axios.defaults.withCredentials=true; //共享 session
//设置axios访问的 默认路径
axios.defaults.baseURL = 'http://localhost:8090'; 
//设置全局 axios变量
Vue.prototype.$ajax = axios;

Vue.config.productionTip = false

import ElementUI from 'element-ui';

/* 导入element-ui样式
*/
import 'element-ui/lib/theme-chalk/index.css'

// 导入reset.css
import '@/assets/reset.css';

Vue.use(ElementUI);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
