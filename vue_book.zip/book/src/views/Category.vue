<template>
  <div style="height:60%">
      <div style="margin-right:450px">
        <el-table
            :data="categorys"
            style="width: 100% "
            align="center"
            @selection-change="handleSelectionChange"
            ref="multipleTable"
            tooltip-effect="dark"
            >
            <el-table-column
                type="selection"
                width="55"
                :show-overflow-tooltip="true"
                >
            </el-table-column>

            <el-table-column
                prop="cid"
                label="分类编号"
                width="100">
            </el-table-column>
            <el-table-column
                prop="cname"
                label="分类名称"
                width="150">
            </el-table-column>
            <el-table-column
                label="操作"
                width="100">
                <template slot-scope="scope">
                    <el-button type="primary" size="small"  icon="el-icon-edit" @click="getByCid(scope.row)">修改</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>

    <div>
        <el-button type="primary" icon="el-icon-delete-solid" @click="delAllCategory()" style="margin-right:20px ; margin-left:450px">删除</el-button>
        <el-button type="primary" icon="el-icon-circle-plus"  @click="openDialog()">新增</el-button>
    </div>

    <!-- 对话框 -->
    <div>
        <el-dialog title="添加分类" :visible.sync="dialogFormVisible">
        <el-form>
            <el-form-item label="分类名称">
            <el-input v-model="addCategory.cname" autocomplete="off"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="add()">确 定</el-button>
        </div>
        </el-dialog>
    </div>

    <!-- 修改对话框 -->
    <div>
        <el-dialog title="修改分类" :visible.sync="dialogFormVisible2">
        <el-form>
            <el-form-item label="分类名称">
            <el-input v-model="updateCategory.cname" autocomplete="off"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible2 = false">取 消</el-button>
            <el-button type="primary" @click="update()">确 定</el-button>
        </div>
        </el-dialog>
    </div>


  </div>
</template>

<script>
import axios from 'axios';  //导入axios请求包
axios.defaults.baseURL = 'http://localhost:8090';  //java后台服务器的http地址

export default {
  data() {
      return {
          categorys : [],  //所有分类对象
          multipleSelection : [] ,  //选择的复选框
          dialogFormVisible: false,  //添加对话框的 展示
          addCategory : {},  //添加的图书对象
          dialogFormVisible2: false,  //  修改对话框的 展示
          updateCategory : {}  //修改的book
      }
    },
    methods:{
        toggleSelection(rows) {
            if (rows) {
                rows.forEach(row => {
                this.$refs.multipleTable.toggleRowSelection(row);});
            } else {
            this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {   //选中绑定数据
            this.multipleSelection = val;
        },
        async findAll(){
            //查询所有的图书 并且带分页
            //es8新语法，简化methods函数方法。  async和await一套
            let {data} = await axios.get("/book/getCategory/");
            this.categorys = data.data;

            // axios.get("/book/getCategory/")
            //     .then(res => {
            //         this.categorys = res.data.data;
            //     })
        },
        delAllCategory(){
           //批量删除 分类
           axios.put("/book/delAllCategory" , this.multipleSelection)
            .then(res => {
                this.findAll();
            })
        },
        getAllCategory(){
           //获取所有的分类
           axios.get("/book/getCategory")
            .then(res => {
                this.categorys = res.data.data;
            })
        },
        add(){
           //添加分类
           axios.post("/book/addCategory" , this.addCategory)
                .then(res => {
                    this.findAll();
                    this.dialogFormVisible = false;  //对话框清掉
                })
        },
        openDialog(){
           //打开 对话框，清空 addCategory
           this.addCategory = {};
           this.dialogFormVisible = true;
        },
        getByCid(category){
           //修改分类的 回显
           axios.get("/book/getCategoryById/"+category.cid)
                .then(res => {
                    this.updateCategory = res.data.data;
                    //展示修改的 对话框
                    this.dialogFormVisible2 = true;
                })
        },
        update(){
           //修改分类
           axios.put("/book/categoryUpdate",this.updateCategory)
                .then(res => {
                    this.dialogFormVisible2 = false;  //隐藏 修改对话框
                    this.findAll();  //重新查询当前页数的数据
                })
        }
       
     },
     created(){
        this.findAll(1);
        this.getAllCategory();
     }
}
</script>

<style>
</style>