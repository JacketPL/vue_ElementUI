<template>
  <div align="center" style="margin-top:10%;margin-right:10% ;">
    <div v-if="cond == 'true'">
        <!-- 进行登录 -->
        <!-- <h2> <i class="el-icon-s-custom"></i>用户登录</h2> -->
        <el-form status-icon   label-width="100px" class="demo-ruleForm" style="width:300px ; padding-top: 30px; padding-right: 60px; padding-bottom: 20px;  border: 1px solid ;  border-radius: 4px">
            <el-form-item label="用户名" >
                <el-input type="text" v-model="user.username" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="密码" >
                <el-input type="password" v-model="user.password" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="login()">登陆</el-button>
                <el-button type="info" @click="resetUser()">重置</el-button>
            </el-form-item>
        </el-form>
    </div>
    <div v-else>
        <el-image :src="src" style="width:10%">
            <div slot="placeholder" class="image-slot">
                加载中<span class="dot">...</span>
            </div>
        </el-image>
        <div style="font-size:30px ;" align='top'>
              <el-avatar src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"></el-avatar>
              已登录用户： {{user.username}} 
            <el-button type="danger" @click="logout()">注 销</el-button>
        </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';  //导入axios请求包
axios.defaults.baseURL = 'http://localhost:8090';  //java后台服务器的http地址

export default {
   data() {
      return {
          user : {}, //登录对象
          cond : true, //是否登录
          src: require('../assets/抱鱼.jpg')
      };
    },
    methods: {
        login(){
            //进行用户登录
            axios.post("/user" , this.user)
                .then(res => {
                    if(res.data.code == "1"){
                        //登录成功跳转到 图书列表
                        this.$router.push("/book");
                    }else{
                        alert(res.data.msg);
                    }
                })
        },
        logout(){
            //注销用户，清除session
            axios.get("/user/logout")
                .then(res => {
                    if(res.data.code == '1'){
                        this.user = {};
                        this.cond = 'true';
                    }
                })
        },
        resetUser(){
            this.user = {};//重置
        }
    },
    created(){
            //初始化属性时，判断是否已经登录
            axios.get("/user")
                .then(res => {
                    if(res.data.code == '0'){
                        //如果为 '' 那么就session中没有登录
                        this.cond = 'true';
                    }else{
                        this.user = res.data.data;
                        this.cond = 'false';
                    }
                })
        }
 }
</script>

<style>
</style>