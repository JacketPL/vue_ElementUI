<template>
  <div style="height:100%">
    
      <div align='center'>
        <el-table
            :data="books"
            style="width: 100% "
            
            @selection-change="handleSelectionChange"
            tooltip-effect="dark"
            >
            <el-table-column
                type="selection"
                width="55"
                >
            </el-table-column>

            <el-table-column
                prop="bid"
                label="图书编号"
                width="120"
                >
                <template slot="header">
                    <el-button type="danger" icon="el-icon-delete-solid" @click="delAllBook()" style="margin-bottom:40px;margin-right:10px">删除</el-button>
                    <h1 style="margin-bottom:20px;margin-left:15px;">图书编号</h1>
                </template>
                <template slot-scope="scope">
                    <p style="margin-left:30px">{{scope.row.bid}}</p>
                </template>
            </el-table-column>
            <el-table-column
                prop="title"
                label="图书名称"
                width="150">
                <template slot="header">
                    <el-button type="success" icon="el-icon-circle-plus" @click="openDialog()" style="margin-bottom:40px;margin-right:10px">新增</el-button>
                    <h1 style="margin-bottom:20px;margin-left:15px">图书名称</h1>
                </template>
                <template slot-scope="scope">
                    {{scope.row.title}}
                </template>
            </el-table-column>
            <el-table-column
                prop="price"
                label="图书价钱"
                width="120">
                <template slot="header">
                    <h1 style="margin-top: 60px;">图书价钱</h1>
                </template>
                <template slot-scope="scope">
                    {{scope.row.price}}
                </template>
            </el-table-column>
            <el-table-column
                prop="category.cname"
                label="分类名称"
                width="120">
                <template slot="header">
                    <h1 style="margin-top: 60px;">分类名称</h1>
                </template>
                <template slot-scope="scope">
                    {{scope.row.category.cname}}
                </template>
            </el-table-column>
            <el-table-column
                label="操作"
                width="100">
                <template slot="header">
                        <h1 style="margin-top: 60px;">操作</h1>
                    </template>
                <template slot-scope="scope">
                    <el-button type="primary" size="small"  icon="el-icon-edit" @click="getByBid(scope.row)">修改</el-button>
                </template>
            </el-table-column>

            <!-- 关键字搜索图书 -->
            <el-table-column
            width="155">
            <!-- slot指定为 header头部， -->
                <template slot="header">
                    <i class="el-icon-search" style="margin-left:10px;margin-top: 60px;">搜索</i>
                    <el-input
                    v-model="baseRequest.search"
                    size="mini"
                    placeholder="输入关键字搜索"
                    @keyup.native="searchBook()"
                    />
                    <!-- 调用一下 scope，上面就不会报错了。 -->
                </template>
                <!-- <template> -->
                    <!-- 标签体 为空，这样 就只会显示一个头部 -->
                <!-- </template> -->
            </el-table-column>
            123
        </el-table>
    </div>
    
    <div style="margin-top:50px;text-align:center;margin-right:200px">
        <el-pagination
        @size-change="setPageSize"
        @current-change="setPageNum"
        :current-page="baseRequest.pageNum"
        :page-sizes="[2, 3, 5, 10]"
        :page-size="baseRequest.pageSize"
        layout="total, sizes, prev, pager, next"
        :total="pages"
        >
        </el-pagination>
    </div>


    <!-- 对话框 -->
    <div>
        <el-dialog title="添加图书" :visible.sync="dialogFormVisible">
        <el-form>
            <el-form-item label="图书名称">
            <el-input v-model="addBook.title" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="价钱">
            <el-input v-model="addBook.price" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="分类">
            <el-select  placeholder="请选择分类" v-model="addBook.category_Id">
                <el-option v-for="(category,index) in categorys" :key="index" :label="category.cname" :value="category.cid"></el-option>
            </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="add()">确 定</el-button>
        </div>
        </el-dialog>
    </div>

    <!-- 修改对话框 -->
    <div>
        <el-dialog title="修改图书" :visible.sync="dialogFormVisible2">
        <el-form>
            <el-form-item label="图书名称">
            <el-input v-model="updateBook.title" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="价钱">
            <el-input v-model="updateBook.price" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="分类">
            <el-select  placeholder="请选择分类" v-model="updateBook.category_Id">
                <el-option v-for="(category,index) in categorys" :key="index" :label="category.cname" :value="category.cid"></el-option>
            </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible2 = false">取 消</el-button>
            <el-button type="primary" @click="update()">确 定</el-button>
        </div>
        </el-dialog>
    </div>

  </div>
</template>

<script>
import axios from 'axios';  //导入axios请求包
axios.defaults.baseURL = 'http://localhost:8090';  //java后台服务器的http地址

export default {
  data() {
      return {
          books : [] , 
          pages : 80 ,
          multipleSelection : [] ,  //选择的复选框
          dialogFormVisible: false,  //添加对话框的 展示
          addBook : {},  //添加的图书对象
          categorys : [],  //所有分类对象
          dialogFormVisible2: false,  //  修改对话框的 展示
          updateBook : {},  //修改的book
          baseRequest : {
              pageNum : 1 ,   //第几页
              pageSize : 2 ,  //每页多少条 默认两条
              search : ''    //搜索条件
          }
      }
    },
    methods:{
        toggleSelection(rows) {   //全不选
            if (rows) {
                rows.forEach(row => {
                this.$refs.multipleTable.toggleRowSelection(row);});
            } else {
            this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {   //选中绑定数据
            this.multipleSelection = val;
        },

        findAll(){
            //查询所有的图书 并且带分页
            axios.get("/book/findAll" , {
                    params : this.baseRequest
                })
                .then(res => {
                    this.books = res.data.data.list;
                    //赋值 所有的条数
                    this.pages = res.data.data.total;
                    //判断当前的 books是否为 空   当最后一页之后的数据全部删除了，那么就会出现 查询暂无数据的bug
                    //如果为空，就表示当前页 数据已经没有了 ， pageNum的往前一页
                    if(this.books == '' && this.baseRequest.pageNum > 1){
                        this.baseRequest.pageNum = this.baseRequest.pageNum-1;
                        this.findAll();  //重新查询所有，查 最后一页
                    }
                })
       },
       delAllBook(){
           //批量删除 book
           axios.put("/book/delAllBook" , this.multipleSelection)
            .then(res => {
                this.findAll();
            })
       },
       getAllCategory(){
           //获取所有的分类
           axios.get("/book/getCategory")
            .then(res => {
                this.categorys = res.data.data;
            })
       },
       add(){
           //添加图书
           axios.post("/book" , this.addBook)
                .then(res => {
                    this.findAll();
                    this.dialogFormVisible = false;  //对话框清掉
                })
       },
       openDialog(){
           //打开 对话框，清空 addBook
           this.addBook = {};
           this.dialogFormVisible = true;
       },
       getByBid(book){
           
           //book即是，当前行的数据对象，是内存中 一块区域的对象地址
           // JSON.parse(JSON.stringify(book)) 将book对象，类似于深度克隆出一个新的对象地址，赋值给updateBook，解决同一对象地址，修改没有提交但是更新地址数据
           this.updateBook = JSON.parse(JSON.stringify(book));

        //    this.updateBook = book;
           //展示修改的 对话框
           this.dialogFormVisible2 = true;

           //修改图书的 回显
        //    axios.get("/book/"+book.bid)
        //         .then(res => {
        //             this.updateBook = res.data.data;
        //             //展示修改的 对话框
        //             this.dialogFormVisible2 = true;
        //         })
       },
       update(){
           //修改图书
           axios.put("/book",this.updateBook)
                .then(res => {
                    this.dialogFormVisible2 = false;  //隐藏 修改对话框
                    this.findAll();  //重新查询当前页数的数据
                })
       },
       searchBook(){
           //当搜索框 改变了数据，就进行数据的 条件的查询，根据 书名模糊查询
           //使用 keyup事件， 键盘按下起来时，访问后台获取数据
            //调用查询所有的方法
            this.findAll(1);
       },
       setPageSize(pageSize){
           //修改每页显示的 几条数据
           this.baseRequest.pageSize = pageSize;
           //调用findAll方法
           this.findAll();
       },
       setPageNum(pageNum){
           //修改每页显示的 几条数据
           this.baseRequest.pageNum = pageNum;
           this.findAll();
       }
       
    },
    created(){
        this.findAll(1);
        this.getAllCategory();
    }
}
</script>

<style>
    /* 获取 第1个 is-leaf的class样式 的孩子样式class */
    .is-leaf:nth-child(1) > .cell{
        margin-top: 60px;
    }
</style>