<template>
  <div style="height:60%" align="center">
      
      <el-table
        :data="books"
        style="width: 100%"
        
        @selection-change="handleSelectionChange"
        
        tooltip-effect="dark"
        >
        <el-table-column
            type="selection"
            width="55"
            :show-overflow-tooltip="true"
            >
        </el-table-column>

        <el-table-column
            prop="bid"
            label="图书编号"
            width="100">
        </el-table-column>
        <el-table-column
            prop="title"
            label="图书名称"
            width="150">
        </el-table-column>
        <el-table-column
            prop="price"
            label="图书价钱"
            width="120">
        </el-table-column>
        <el-table-column
            prop="category.cname"
            label="分类名称"
            width="120">
        </el-table-column>
         <el-table-column
            label="操作"
            width="70">
            <template slot-scope="scope">
                <el-button type="text" size="small" @click="getByBid(scope.row)">修改</el-button>
            </template>
        </el-table-column>

        <!-- 关键字搜索图书 -->
        <el-table-column
        width="155">
        <!-- slot指定为 header头部， 需要绑定 slot-scope，否则数据无法输入到 文本框中 -->
            <template slot="header" slot-scope="scope">
                <el-input
                v-model="search"
                size="mini"
                placeholder="输入关键字搜索"
                @keyup.native="searchBook()"/>
                <!-- 调用一下 scope，上面就不会报错了。 -->
                {{scope.row}}
            </template>
            <!-- <template> -->
                <!-- 标签体 为空，这样 就只会显示一个头部 -->
            <!-- </template> -->
        </el-table-column>
    </el-table>

    <div style="width:600px;height:100px;background-position:left top" align="left">
            <el-button @click="delAllBook()" style="">删除</el-button>
            <el-button @click="openDialog()">新增</el-button>
    </div>

    <div>
        <el-pagination
            background
            layout="prev, pager, next"
            :total="pages" 
            @current-change="findAll"
            @prev-click="findAll"
            @next-click="findAll"
            >
        </el-pagination>
    </div>

    <!-- 对话框 -->
    <div>
        <el-dialog title="添加图书" :visible.sync="dialogFormVisible">
        <el-form>
            <el-form-item label="图书名称">
            <el-input v-model="addBook.title" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="价钱">
            <el-input v-model="addBook.price" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="分类">
            <el-select  placeholder="请选择分类" v-model="addBook.category_Id">
                <el-option v-for="(category,index) in categorys" :key="index" :label="category.cname" :value="category.cid"></el-option>
            </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="add()">确 定</el-button>
        </div>
        </el-dialog>
    </div>

    <!-- 修改对话框 -->
    <div>
        <el-dialog title="修改图书" :visible.sync="dialogFormVisible2">
        <el-form>
            <el-form-item label="图书名称">
            <el-input v-model="updateBook.title" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="价钱">
            <el-input v-model="updateBook.price" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="分类">
            <el-select  placeholder="请选择分类" v-model="updateBook.category_Id">
                <el-option v-for="(category,index) in categorys" :key="index" :label="category.cname" :value="category.cid"></el-option>
            </el-select>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible2 = false">取 消</el-button>
            <el-button type="primary" @click="update()">确 定</el-button>
        </div>
        </el-dialog>
    </div>

  </div>
</template>

<script>
import axios from 'axios';  //导入axios请求包
axios.defaults.baseURL = 'http://localhost:8090';  //java后台服务器的http地址

export default {
  data() {
      return {
          books : [] , 
          pages : 80 ,
          multipleSelection : [] ,  //选择的复选框
          dialogFormVisible: false,  //添加对话框的 展示
          addBook : {},  //添加的图书对象
          categorys : [],  //所有分类对象
          getPageNum : 1, //当前点击的 页数是第几页
          dialogFormVisible2: false,  //  修改对话框的 展示
          updateBook : {},  //修改的book
          search : ''  // 搜索框
      }
    },
    methods:{
        toggleSelection(rows) {   //全不选
            if (rows) {
                rows.forEach(row => {
                this.$refs.multipleTable.toggleRowSelection(row);});
            } else {
            this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {   //选中绑定数据
            this.multipleSelection = val;
        },
        findAll(pageNum){
            //将当前查询的 pageNum页数 赋值到 data中
            this.getPageNum = pageNum;
            //判断search是否为 '' 空
            if(this.search == ''){
                this.search = null;
            }
            //查询所有的图书 并且带分页
            axios.get("/book/getAll/"+pageNum+"/"+this.search)
                .then(res => {
                    this.books = res.data.data.list;
                    //赋值 所有的页数
                    this.pages = res.data.data.pages*10;
                    //判断当前的 books是否为 空
                    if(this.books == '' && pageNum > 1){
                        this.findAll(pageNum-1);  //重新查询所有，往前一页查询
                    }
                })
       },
       delAllBook(){
           //批量删除 book
           axios.put("/book/delAllBook" , this.multipleSelection)
            .then(res => {
                this.findAll(this.getPageNum);
            })
       },
       getAllCategory(){
           //获取所有的分类
           axios.get("/book/getCategory")
            .then(res => {
                this.categorys = res.data.data;
            })
       },
       add(){
           //添加图书
           axios.post("/book" , this.addBook)
                .then(res => {
                    this.findAll(this.getPageNum);
                    this.dialogFormVisible = false;  //对话框清掉
                })
       },
       openDialog(){
           //打开 对话框，清空 addBook
           this.addBook = {};
           this.dialogFormVisible = true;
       },
       getByBid(book){

       	   //book即是，当前行的数据对象，是内存中 一块区域的对象地址
           // JSON.parse(JSON.stringify(book)) 将book对象，类似于深度克隆出一个新的对象地址，赋值给updateBook，解决同一对象地址，修改没有提交但是更新地址数据
           this.updateBook = JSON.parse(JSON.stringify(book));
           
	   //    this.updateBook = book;
           //展示修改的 对话框
           this.dialogFormVisible2 = true;

           //修改图书的 回显
           //axios.get("/book/"+book.bid)
           //     .then(res => {
            //        this.updateBook = res.data.data;
             //       //展示修改的 对话框
            //        this.dialogFormVisible2 = true;
             //   })
       },
       update(){
           //修改图书
           axios.put("/book",this.updateBook)
                .then(res => {
                    this.dialogFormVisible2 = false;  //隐藏 修改对话框
                    this.findAll(this.getPageNum);  //重新查询当前页数的数据
                })
       },
       searchBook(){
           //当搜索框 改变了数据，就进行数据的 条件的查询，根据 书名模糊查询
           //使用 keyup事件， 键盘按下起来时，访问后台获取数据
            //调用查询所有的方法
            this.findAll(1);
       }
       
    },
    created(){
        this.findAll(1);
        this.getAllCategory();
    }
}
</script>

<style>
</style>