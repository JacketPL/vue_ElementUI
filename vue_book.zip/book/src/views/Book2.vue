<template>
  <div>
    <!-- <h1>学生列表</h1> -->
    <!-- 面包屑 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/home' }">管理系统</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/home/students' }">班级管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 添加弹出框 -->
    <el-dialog title="添加" :visible.sync="dialogFormVisible">
      <el-form>
        <el-form-item label="学生名" :label-width="formLabelWidth">
          <el-input v-model="student.name" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" :label-width="formLabelWidth">
          <el-input v-model="student.password" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="年龄" :label-width="formLabelWidth">
          <el-input v-model="student.age" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="性别" :label-width="formLabelWidth">
          <el-radio v-model="student.sex" label="男">男</el-radio>
          <el-radio v-model="student.sex" label="女">女</el-radio>
        </el-form-item>
        <el-date-picker v-model="student.birthday" type="date" placeholder="生日"></el-date-picker>
        <el-form-item label="所在班级" :label-width="formLabelWidth">
          <el-select v-model="student.cid" placeholder="请选择班级...">
            <el-option label="一班" value="1"></el-option>
            <el-option label="二班" value="2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible=false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible=false">确 定</el-button>
      </div>
    </el-dialog>
    <el-row :gutter="10">
      <!-- 添加/刷新/批量删除 -->
      <el-col :span="2">
        <div class="bg-purple">
          <el-button
            type="primary"
            icon="el-icon-circle-plus-outline"
            @click="dialogFormVisible=true"
          ></el-button>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="bg-purple">
          <el-button type="primary" icon="el-icon-refresh"></el-button>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="bg-purple">
          <el-button type="primary" icon="el-icon-delete"></el-button>
        </div>
      </el-col>
      <!-- 模糊查询 -->
      <el-col :span="4" :offset="12">
        <div class="bg-purple">
          <el-input placeholder="请输入..." v-model="likename" class="input" clearable></el-input>
        </div>
      </el-col>
      <el-col :span="1">
        <div class="bg-purple">
          <el-button type="primary" icon="el-icon-zoom-in"></el-button>
        </div>
      </el-col>
    </el-row>
    <!-- 学生列表 -->
    <el-table :data="pageInfo.list" border style="width: 100%" max-height="1000">
      <el-table-column type="selection" width="80"></el-table-column>
      <el-table-column prop="sid" label="学生编号" width="150"></el-table-column>
      <el-table-column prop="name" label="学生名" width="150"></el-table-column>
      <el-table-column prop="age" label="年龄" width="150"></el-table-column>
      <el-table-column prop="sex" label="性别" width="150"></el-table-column>
      <el-table-column prop="birthday" label="请选择生日..." width="150"></el-table-column>
      <el-table-column prop="clazz.name" label="所属班级..." width="150"></el-table-column>
      <el-table-column label="操作" width="150">
        <template>
          <!-- slot-scope="scope" -->
          <el-button type="text" size="small">移除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageRequest.pageNum"
      :page-sizes="[1, 2, 3, 4]"
      :page-size="pageRequest.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="pageInfo.total"
    ></el-pagination>
  </div>
</template>

<script>
export default {
  data() {
    return {
      likename: "",
      pageInfo: [],
      student: {},
      //分页对象（当前页，每页条数）
      pageRequest: { pageNum: 1, pageSize: 3 },
      dialogFormVisible: false,
      formLabelWidth: "120px"
    };
  },
  methods: {
    async findStudent() {
      let { data } = await this.$http.get("/student", {
        params: this.pageRequest
      });
      this.pageInfo = data.data;
    },
    // 每页条数改变
    async handleSizeChange(val) {
      this.pageRequest.pageSize = val;
      this.findStudent();
    },
    // 当前页改变
    async handleCurrentChange(val) {
      this.pageRequest.pageNum = val;
      this.findStudent();
    }
  },
  created() {
    this.findStudent();
  }
};
</script>

<style scoped>
.input {
  width: 250px;
}

/* .bg-purple {
  background: #d3dce6;
} */

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>