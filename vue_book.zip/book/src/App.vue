<template>
  <div id="app"  style="height:900px">
      <el-container>
          <el-header 
            style="height:100px;"
          >
              <h1 style="font-size:40px ; color: white; text-align:center ; margin-top: 15px;">传智高中</h1>
          </el-header>
          <el-container>
            <el-aside width="150px">
                <el-menu
                  :default-active="$route.path"
                  :router="true"

                  style="height:100%"
                  class="el-menu-vertical-demo"
                  background-color="#545c64"
                  text-color="#fff"
                  active-text-color="#ffd04b">
                  <el-menu-item index="/login">
                      <i class="el-icon-s-custom"></i>
                      <span>登录</span>
                  </el-menu-item>
                  <el-menu-item index="/category">
                    <i class="el-icon-s-grid"></i>
                    <span slot="title">所有分类</span>
                  </el-menu-item>

                  <el-menu-item index="/book">
                    <i class="el-icon-reading"></i>
                    <span slot="title">所有图书</span>
                  </el-menu-item>
                </el-menu>
            </el-aside>
            <el-main>
                <router-view></router-view>
            </el-main>
          </el-container>
      </el-container>
  </div>
</template>

<style>
  /*
    找到html标签、body标签，和挂载的标签
    都给他们统一设置样式
  */
  html,body,#app,.el-container{
        /*设置内部填充为0，几个布局元素之间没有间距*/
        padding: 0px;
         /*外部间距也是如此设置*/
        margin: 0px;
        /*统一设置高度为100%*/
        height: 100%;
  }

  .el-header, .el-footer {
    background-color:#545c64;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 200px;
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    /* text-align: center; */
    /* line-height: 160px;  cnm,傻逼样式 */
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>
